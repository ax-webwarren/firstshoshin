from django.shortcuts import render
from django.http import HttpResponse, HttpResponseRedirect
from django.template import loader
from . models import Users, UserRegistrationForm
from django.contrib.auth import authenticate, login
from django.contrib.auth.models import User

# Create your views here.
def index(request):
    User_list = Users.objects.order_by('id')[:5]
    template = loader.get_template('index.html')
    context = {
        'Users': User_list,
        #for NavBar
        'home': 'active'
    }
    return HttpResponse(template.render(context, request))

#@csrf_protect
def register(request):    
    template = loader.get_template('registration.html') 
    if request.method == 'POST':
        form = UserRegistrationForm(request.POST, request.FILES)        
        if form.is_valid():
            firstname = request.POST['firstname']
            lastname = request.POST['lastname']
            username = request.POST['username']
            password = request.POST['password']
            email = request.POST['email']
            # Create User
            user_profile = User.objects.create_user(username, email, password)
            user_profile.first_name = firstname
            user_profile.last_name = lastname
            user_profile.save()            
            user_upload = form.save()            
            # Create User Profile
            user_upload.user = user_profile
            user_upload.save()
            return HttpResponseRedirect("/profile/%s" % user_profile)
    else:
        form = UserRegistrationForm()       
    context = {
        'form': form,
        #for NavBar
        'register': 'active'
    }
    return HttpResponse(template.render(context, request))

def user_login(request):
    template = loader.get_template('login.html')
    error = "" 
    # User Login
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return HttpResponseRedirect("/profile/%s" % user)      
        else:
            error = "Incorrect Login Credentials."
    context = {
        'error': error,
        #for NavBar
        'login': 'active'
    }
    return HttpResponse(template.render(context, request))

def profile(request, user_profile=None):
    if request.user.username:
        User_list = User.objects.get(username=request.user.username)
    else:
        User_list = User.objects.first()
    # Custom User Profile
    if user_profile:
        User_list = User.objects.get(username=user_profile)
    # Update User Profile
    if request.method == 'POST':
        form = UserRegistrationForm(request.POST, request.FILES, instance=User_list)        
        if form.is_valid():
            firstname = request.POST['firstname']
            lastname = request.POST['lastname']
            username = request.POST['username']
            password = request.POST['password']
            email = request.POST['email']
            # Update User
            if User_list:
            	user_profile = User_list
            else:
            	user_profile = User.objects.get(username=username)
            user_profile.first_name = firstname
            user_profile.last_name = lastname
            user_profile.save()            
            # Update User Profile
            user_upload = form.save()            
            return HttpResponseRedirect("/profile/%s" % user_profile)
    else:
        form = UserRegistrationForm()

    template = loader.get_template('profile.html')
    context = {
        'form': form,
        'User': User_list,
        #for NavBar
        'profile': 'active'
    }
    return HttpResponse(template.render(context, request))