from django.db import models
from django.contrib.auth.models import User
from django import forms

# Create your models here.
class Users(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    profile_pic = models.FileField(upload_to="static")

    class Meta:
        verbose_name = 'User Profile'
        verbose_name_plural = 'User Profiles'

class UserRegistrationForm(forms.ModelForm):
	class Meta:
		model = Users
		fields = ('profile_pic',)